#!/bin/bash

AXIS_HOME=./axis-1_3
JAVAMAIL_HOME=./javamail-1.3.3_01
JAVA_ACTIVATION_HOME=./jaf-1.0.2

CLASSPATH=./pdfg_client.jar:
CLASSPATH=$CLASSPATH:$AXIS_HOME/lib/axis.jar
CLASSPATH=$CLASSPATH:$AXIS_HOME/lib/axis-ant.jar
CLASSPATH=$CLASSPATH:$AXIS_HOME/lib/commons-discovery-0.2.jar
CLASSPATH=$CLASSPATH:$AXIS_HOME/lib/commons-logging-1.0.4.jar
CLASSPATH=$CLASSPATH:$AXIS_HOME/lib/jaxrpc.jar
CLASSPATH=$CLASSPATH:$AXIS_HOME/lib/log4j-1.2.8.jar
CLASSPATH=$CLASSPATH:$AXIS_HOME/lib/saaj.jar
CLASSPATH=$CLASSPATH:$AXIS_HOME/lib/wsdl4j-1.5.1.jar
CLASSPATH=$CLASSPATH:$JAVA_ACTIVATION_HOME/activation.jar
CLASSPATH=$CLASSPATH:$JAVAMAIL_HOME/mail.jar

java -classpath $CLASSPATH com.adobe.livecycle.samples.pdfgenerator.cmdlineclient.CmdLineClient $1 $2 $3 $4 $5

