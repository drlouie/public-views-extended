
/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2005 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

using System;
using System.IO;
using System.Threading;

using System.Web;
using System.Web.Services;
using Microsoft.Web.Services2.Dime;
using Microsoft.Web.Services2.Attachments;
using Microsoft.Web.Services2;
using DimeTestWSApp.PdfgWSProxy;

namespace DimeTestWSApp
{
	/// <summary>
	/// PDF Generator web service test client
	/// </summary>
	/// 

	class WSDimeTest
	{

		/// <summary>
		/// PDF Generator web service test client
		/// </summary>
		[STAThread]
		static void Main(String[] args)
		{
			
			//
			// specify the web service URL
			// specify the name of the input file
			//

			String Url = "http://localhost:8080/pdfg-ws/services/PdfGenInterface";
			String sourceFilename = "c:/testpath/in/test.doc";

			//
			// initialize the reference to the web service 
			//
			
			PdfgWSProxy.PdfGenWse pdfgWS = null;
			try
			{
				pdfgWS = new PdfgWSProxy.PdfGenWse();

				//
				// Set target URL to what we want
				//

				pdfgWS.Url = Url;
			}
			catch(Exception e)
			{
				Console.WriteLine("Caught Exception: Constructor(" + Url + ") : " + e.Message);
				Console.WriteLine(e.StackTrace);
				Environment.Exit(1);
			}
			
			Console.WriteLine();
			Console.WriteLine("sourceFilename="+sourceFilename);
			Console.WriteLine("Target host: " + pdfgWS.Url);
			Console.WriteLine();

			//
			// convert the filename string to a FileInfo object for convenience
			//
			
			FileInfo sourceFile = new FileInfo(sourceFilename);
			string filepath = sourceFile.FullName;

			Console.WriteLine("-------------------------------------------");

			try 
			{

				//
				// create reference objects for the web service methods
				//

				getConfigRequestType configRequest = new getConfigRequestType();
				getConfigResponseType configResponse = pdfgWS.getConfigurationXML(configRequest);
			
				//
				// create reference object for submitJob 
				//

				SubmitJobRequestType submitRequest = new SubmitJobRequestType();
			
				//
				// specify the job details
				// note: sourceType = Dime attachment
				//

				FileInfo fInfo 				= new FileInfo(filepath);
				submitRequest.filename		= fInfo.Name;
				submitRequest.jobConfig		= configResponse.configXML;
				submitRequest.sourceType	= 0;
				submitRequest.locale		= "en_US";
			
				Console.WriteLine("Submitting file	: " + filepath);
				Console.WriteLine();
				Console.WriteLine("\nSending PDFG Soap request submitJob()... ");

				//
				//	add dime attachment
				// 

				DimeAttachment attach = new DimeAttachment(
					System.Guid.NewGuid().ToString(),
					"application/octet-stream",
					TypeFormat.MediaType, 
					filepath);
				pdfgWS.RequestSoapContext.Attachments.Add(attach);

				//
				// submit the job request
				//
				
				SubmitJobResponseType submitResponse = pdfgWS.submitJob(submitRequest);		
				pdfgWS.RequestSoapContext.Attachments.Clear();


				int retCode = submitResponse.returnCode;
				if (retCode == 0) 
				{
					Console.WriteLine("submitJob() return Code: " + submitResponse.returnCode.ToString());

					//
					// get the conversion job id
					//

					String jobId = submitResponse.jobID;
					String resultFPath = getResultFilePath(filepath);

					//
					// Pick up results
					//

					int 	status		= -1;
					int attachmentFormat=  0; // ask for DIME format in return SOAP attachment
						
					Console.WriteLine("\njob ID: " + jobId);
				
					//
					// create reference for job results 
					//

					getJobResultsRequestType getResultsRequest = new getJobResultsRequestType();
					getJobResultsResponseType getResultsResponse = null;
				
					//
					// set up parameters for the job results request
					//

					getResultsRequest.jobID = jobId;
					getResultsRequest.resultAttachmentFormat = attachmentFormat;

					//
					// request the job status continuously until we get some result
					//
					
					do 
					{
						//
						// wait 1000 milliseconds so this loop
						// doesn't kill the CPU
						//

						Thread.Sleep(1000);
						Console.WriteLine("\nChecking Status...");
						Console.WriteLine("\nSending PDFG Soap request getJobResults()... ");
						
						//
						// get the job results
						//

						getResultsResponse = pdfgWS.getJobResults(getResultsRequest);

						//
						// get the job status and return code
						//

						status = getResultsResponse.jobStatus;
						retCode = getResultsResponse.returnCode;
						
						Console.WriteLine("Job ID: " + jobId);
						Console.WriteLine("Status: " + status.ToString());
						
					} while((retCode == 0) && (status == 1));
					
					//
					// check the return codes and status to see
					// if there was a problem
					//

					if ((retCode == 0) && (status == 0)) 
					{					

						//
						// display the name of the resulting output file (if it exists)
						//

						try
						{
							if (pdfgWS.ResponseSoapContext.Attachments.Count > 0) 
							{
								FileStream fstream = File.Create(resultFPath);

								// only get the first attachment:
								copyStreams(pdfgWS.ResponseSoapContext.Attachments[0].Stream, fstream);
								fstream.Close();

								Console.WriteLine("ResultFile: " + resultFPath);
							} 
							else 
							{
								Console.WriteLine("ResultFile: null (no attachment found OR problem extracting attachment)");
							}
						}
						catch(Exception e)
						{
							Console.WriteLine("Caught Exception: ExtractDimeAttachment(" + resultFPath + ") " + e.Message);
							Console.WriteLine(e.StackTrace);
						}

						//
						// check if the result contains JDF data
						//

						getJDF(getResultsResponse.jdfData, changeExtension(resultFPath, ".jdf"));
					} 
					else 
					{
						Console.WriteLine("getResults() returns error: Code: " + retCode.ToString() + " Message: " + getResultsResponse.returnMessage);
					}
					
					//
					// we are done, do delete the job
					//

					Console.WriteLine("\nDeleting job : " + jobId);
					
					deleteJobRequestType request = new deleteJobRequestType();
					request.jobID = jobId;
					deleteJobResponseType deleteResponse = pdfgWS.deleteJob(request);
					
					int delRetCode = deleteResponse.returnCode;
					int delStatus = deleteResponse.jobStatus;
			
					Console.WriteLine("Job ID: " + jobId);
					Console.WriteLine("Job Status: " + delStatus.ToString());
					Console.WriteLine("Error Code: " + delRetCode.ToString());

					if (delRetCode != 0) 
					{
						Console.WriteLine("deleteJob() returns error: Code: " + delRetCode.ToString() + " Message: " + deleteResponse.returnMessage);
					}

				} 
				else 
				{
					Console.WriteLine("submitJob() returns error: Code: " + retCode.ToString() + " Message: " + submitResponse.returnMessage);
				}
			}
			catch (Exception e)
			{
				Console.WriteLine("\nCaught exception: " + e.ToString());
				Console.WriteLine();
				Console.WriteLine(e.StackTrace);
			}

			Console.WriteLine();

			// Done
			Console.WriteLine("-------------------------------------------");
			Console.WriteLine();
			Console.WriteLine();

			Console.WriteLine("PDFG WS Job Done.");
		}

		private static void getJDF(String jdfStr, String filepath) 
		{

			//
			// check if the result contains JDF data
			//

			if ((jdfStr != null) && (jdfStr.Length > 0)) 
			{

				//
				// there is JDF data so output it to a file
				//

				StreamWriter jdfFile = new StreamWriter(filepath);
				jdfFile.Write(jdfStr);
				jdfFile.Close();
				Console.WriteLine("Jdf File written: " + filepath);
			}
					
		}

		private static long copyStreams(System.IO.Stream istream, FileStream ostream) 
		{
			int bufSize = 32 * 1024;		// 3k buffer
			byte[] buff = new byte[bufSize];	
			long bytesWritten = 0L;
			int bytesRead = 0;
        
			while ((bytesRead = istream.Read(buff, 0, bufSize)) > 0)
			{
				ostream.Write(buff, 0, bytesRead);
				bytesWritten += bytesRead;
			}
			ostream.Flush();

			return bytesWritten;       	
		}

		private static String getResultFilePath(String inputFPath) 
		{
			FileInfo  fi = new FileInfo(inputFPath);
			DirectoryInfo di = fi.Directory;
			DirectoryInfo dip = di.Parent;

			String resultFPath = dip.FullName + "\\out\\" + changeExtension(fi.Name, ".pdf");
			return resultFPath;
		}

		private static String changeExtension(String originalName, String newExtension) 
		{
			int lastDot = originalName.LastIndexOf(".");
			if (lastDot != -1) 
			{
				return originalName.Substring(0, lastDot) + newExtension;
			} 
			else 
			{
				return originalName + newExtension;
			}
		}

	}

}
