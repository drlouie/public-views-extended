/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

package com.adobe.livecycle.samples.pdfgenerator.webui;

import java.io.DataInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

/**
 * Class that handles uploading files from a web form to a servlet. Note the
 * parameters have to parsed out in a much different way than a normal web form
 * post as the form has data type is specified as ENCTYPE='multipart/form-data'
 * 
 * @author slegge
 * 
 */
public class UploadHandler
{

	//
	// place holder for the regular form parameters
	//
	private HashMap _hmParameters;

	public UploadHandler()
	{
		_hmParameters = new HashMap();
	}

	/**
	 * Basic getter for the parameters, returns a hashmap of parameters; that
	 * is, a map of key=value strings.
	 * 
	 * @return
	 */
	public HashMap getParameters()
	{
		return _hmParameters;
	}

	/**
	 * Handles the form post which is attempting to upload a file to the
	 * servlet. Gets all the required info from the HttpServletRequest.
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public UploadedFile handleUpload(HttpServletRequest request)
			throws Exception
	{

		UploadedFile uploadedFile = null;

		String contentType = request.getContentType();

		//
		// If the content type is a multipart/form-data then a file has just
		// been uploaded
		//

		if ((contentType != null)
				&& (contentType.indexOf("multipart/form-data") >= 0))
		{

			String boundary = contentType.substring(contentType
					.indexOf("boundary=") + 9);

			DataInputStream in = new DataInputStream(request.getInputStream());
			int dataLength = request.getContentLength();

			//
			// Read data from input stream Read the bytes until all are received
			//

			byte dataBytes[] = new byte[dataLength];
			int byteRead = 0;
			int totalBytesRead = 0;
			while (totalBytesRead < dataLength)
			{
				byteRead = in.read(dataBytes, totalBytesRead, dataLength);
				totalBytesRead += byteRead;
			}
			String dataString = new String(dataBytes);

			//
			// get the component which are files
			//

			int fileCount = 0;
			List formComponents = getFormComponents(dataString, dataBytes,
					boundary);
			for (Iterator it = formComponents.iterator(); it.hasNext();)
			{

				//
				// get the filename
				//

				byte[] component = (byte[]) it.next();
				String fileName = getFileName(component);

				//
				// if there's no filename then read the data as a regular parameter
				//

				if (fileName == null)
				{
					readParameter(component);
				}

				//
				// Consider only the "file" components in the form
				//

				if ((fileName != null) && (!fileName.equals("")))
				{

					//
					// get the file data
					//

					byte[] fileData = getFileData(component);
					uploadedFile = new UploadedFile(fileName, fileData);

				}
			}
		}
		if (uploadedFile == null)
		{
			throw new Exception("Unable to read file during upload attempt.");
		}
		return uploadedFile;

	}

	/**
	 * Parses the input data and builds a list with all form components
	 * 
	 * @param data
	 * @param dataBytes
	 * @param boundary
	 * @return
	 */
	private List getFormComponents(String data, byte[] dataBytes,
			String boundary)
	{

		//
		// The components in a multipart/form-data are separated by "--boundary"
		// (boundary prefixed by "--").  Parse the data out.
		//

		String separator = "--" + boundary;
		ArrayList components = new ArrayList();
		int idx = data.indexOf(separator);
		while (idx > -1)
		{
			int nextIdx = data.indexOf(separator, idx + separator.length());
			if (nextIdx > -1)
			{
				int startpos = data.substring(0, idx + separator.length())
						.getBytes().length;

				//
				// skip the trailing '\r\n' characters
				//

				int endpos = data.substring(0, nextIdx - 2).getBytes().length;
				String component = data.substring(idx + separator.length(),
						nextIdx - 2);
				if (component.indexOf("Content-Disposition") > 0)
				{
					components.add(getBytes(dataBytes, startpos, endpos));
				}
			}
			idx = nextIdx;
		}
		return components;
	}

	/**
	 * Utility method that returns a portion of the provided byte array.
	 * @param data
	 * @param start
	 * @param end
	 * @return
	 */
	private byte[] getBytes(byte[] data, int start, int end)
	{
		//
		// return the bytes in the provided array at positions defined by
		// start to end parameters
		//

		byte[] subdata = new byte[end - start];
		for (int i = start; i < end; i++)
		{
			subdata[i - start] = data[i];
		}
		return subdata;
	}

	/**
	 * The method returns the file name for form a form component If the
	 * component is not a file, returns null;
	 * 
	 * @param component
	 * @return
	 */
	private String getFileName(byte[] componentBytes)
	{
		String component = new String(componentBytes);
		String fileName = null;
		int fileNameIdx = component.indexOf("filename=\"");
		if (fileNameIdx > -1)
		{
			//
			// Parse the absolute path and get only the file name
			//

			fileName = component.substring(fileNameIdx + 10);
			fileName = fileName.substring(0, fileName.indexOf("\""));
			fileName = fileName.substring(fileName.lastIndexOf("\\") + 1);
		}
		return fileName;
	}

	/**
	 * Reads the form parameter name and value from the componentBytes and
	 * stores it in the _hmParameters hashmap
	 */
	private void readParameter(byte[] componentBytes)
	{
		String component = new String(componentBytes);
		String paramName = "";
		int paramNameIdx = component.indexOf("name=\"");
		if (paramNameIdx > -1)
		{

			//
			// Parse the absolute path and get only the file name
			//

			paramName = component.substring(paramNameIdx + 6);
			paramName = paramName.substring(0, paramName.indexOf("\""));
		}
		String paramValue = "";
		int paramValueIdx = component.indexOf("\r\n\r\n");
		if (paramValueIdx > -1)
		{
			paramValue = component.substring(paramValueIdx + 4);
		}
		_hmParameters.put(paramName, paramValue);
	}

	/**
	 * The method returns the file content from a form component
	 * 
	 * @param component
	 * @return
	 */
	private byte[] getFileData(byte[] componentBytes)
	{
		String component = new String(componentBytes);
		//
		// skip "Content-Disposition" part
		//
		int start = component.indexOf("filename=\"");
		start = component.indexOf("\n", start) + 1;
		//
		// skip "Content-Type" part (if present)
		//
		start = component.indexOf("\n", start) + 1;
		//
		// skip one more "\n"
		//
		start = component.indexOf("\n", start) + 1;

		return getBytes(componentBytes, component.substring(0, start)
				.getBytes().length, componentBytes.length);
	}

}
