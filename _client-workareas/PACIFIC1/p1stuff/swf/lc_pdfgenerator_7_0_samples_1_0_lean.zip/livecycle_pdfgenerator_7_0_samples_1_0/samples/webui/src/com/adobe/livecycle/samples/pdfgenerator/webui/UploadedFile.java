/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

package com.adobe.livecycle.samples.pdfgenerator.webui;

/**
 * Utility class used by WebUIServlet to handle uploading a file from a JSP to a
 * Servlet. This class represents and uploaded file.
 * 
 * @author slegge
 * 
 */
public class UploadedFile
{

	//
	// the filename of the uploaded file
	//
	private String _sFilename;

	//
	// the byte data of the uplaoded file
	//
	private byte[] _fileData;

	/**
	 * Constructor accepts filename and byte data for the uploaded file.
	 * 
	 * @param sFilename
	 * @param fileData
	 */
	public UploadedFile(String sFilename, byte[] fileData)
	{
		_sFilename = sFilename;
		_fileData = fileData;
	}

	/**
	 * Basic getter for the filename. Returns a string.
	 * 
	 * @return
	 */
	public String getFilename()
	{
		return _sFilename;
	}

	/**
	 * Basic getter for the byte data. Returns an array of byte.
	 * 
	 * @return
	 */
	public byte[] getFileData()
	{
		return _fileData;
	}

}
