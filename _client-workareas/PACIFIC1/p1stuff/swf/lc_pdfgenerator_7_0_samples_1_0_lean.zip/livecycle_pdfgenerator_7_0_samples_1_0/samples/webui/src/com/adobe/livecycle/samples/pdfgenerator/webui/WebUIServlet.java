/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

package com.adobe.livecycle.samples.pdfgenerator.webui;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.adobe.livecycle.samples.pdfgenerator.PdfGenAccess;

/**
 * Sample servlet which handles the uploading of a file and the submission of
 * that file to the PDF Generator web service for conversion into a PDF file.
 *
 * @author slegge
 *
 */
public class WebUIServlet extends HttpServlet
{

	//
	// Specify the location of the webapp/ROOT directory for the tomcat
	// server. Specify the URL representation of that directory. This
	// sample servlet uses these values to know where to store the generated
	// PDF and also how to build a URL so the user can access the PDF
	// via an html link.
	//

	private String REPOSITORY_DIR = "C:/Program Files/Apache Group/Tomcat 4.1/webapps/ROOT";

	private String REPOSITORY_URL = "http://localhost:8080/";

	/**
	 * Basic servlet doGet which, for convenience, is redirected to the doPost
	 * method.
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doPost(req, res);
	}

	/**
	 * Basic doPost method which handles the request to the servlet, parses the
	 * form data and then submits the file to the PDF Generator web service for
	 * conversion into a PDF file.
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{

		//
		// Specify the URL of the PDF Generator web service WSDL
		//

		String sWebServiceURL = "http://localhost:8080/pdfg-ws/services/PdfGenInterface?wsdl";

		//
		// create the file repository directory if it does not exist
		//

		File repositoryDir = new File(REPOSITORY_DIR);
		repositoryDir.mkdirs();

		//
		// utility variables
		//

		boolean bError = false;
		String sErrorText = "";

		String sInputFilename = "";
		String sOutputFilename = "";

		HashMap formParameters = new HashMap();

		try
		{
			UploadHandler uploadHandler = new UploadHandler();
			UploadedFile uploadedFile = uploadHandler.handleUpload(req);

			//
			// get the parameters from the uploadHandler instead of the HttpServletRequest
			// because the form uses ENCTYPE='multipart/form-data' so we can
			// handle the upload of the file to convert; the parameters have
			// to be read in a different way
			//

			formParameters = uploadHandler.getParameters();

			byte[] fileData = uploadedFile.getFileData();

			sInputFilename = repositoryDir.getCanonicalPath() + "/"
					+ uploadedFile.getFilename();

			//
			// write a copy of the uploaded file to the servlet's file repository
			//

			FileOutputStream fos = new FileOutputStream(
					new File(sInputFilename));
			fos.write(fileData);
			fos.close();

			//
			// determine an output file name based on the input file name
			//

			File file = new File(uploadedFile.getFilename());
			sOutputFilename = file.getName();
			if (sOutputFilename.lastIndexOf(".") > -1)
			{
				sOutputFilename = sOutputFilename.substring(0, sOutputFilename
						.lastIndexOf("."))
						+ ".pdf";
			}

		} catch (Exception x)
		{
			bError = true;
			sErrorText = x.getMessage();
		}

		//
		// determine if the user selected to password enable the PDF
		//

		boolean bPasswordProtected = "on".equals((String) formParameters
				.get("passwordprotected"));

		//
		// get the password entered by the user in the web form validate
		// it so it's non-null
		//

		String sPassword = (String) formParameters.get("password");
		sPassword = (sPassword != null) ? sPassword : "";

		if (!bError)
		{
			PdfGenAccess gen = new PdfGenAccess();
			try
			{
				File inputFile = new File(sInputFilename);
				String sSourceDir = inputFile.getParent();
				String sSourceFilename = inputFile.getName();

				//
				// load the default webui_config.xml file
				//

				String sXmlConfigFileName = REPOSITORY_DIR
						+ "/webui_config.xml";
				String sConfigXML = "";
				try
				{

					File file = new File(sXmlConfigFileName);
					sConfigXML = file2String(file);

				} catch (Exception x)
				{
					x.printStackTrace();
				}

				//
				// replace the $PASSWORD token in the default config xml with the
				// password the user entered in the web form
				//

				String sOldText = "$PASSWORD";
				String sNewText = "";
				if (bPasswordProtected)
				{
					sNewText = sPassword;
				}
				StringBuffer sb = new StringBuffer(sConfigXML);
				int iStart = sb.indexOf("$PASSWORD");
				int iEnd = iStart + sOldText.length();
				sConfigXML = sb.replace(iStart, iEnd, sNewText).toString();

				gen.generatePDF(sWebServiceURL, sSourceDir, sSourceFilename,
						repositoryDir.getCanonicalPath(), sConfigXML);
			} catch (Exception e)
			{
				bError = true;
				sErrorText = e.getMessage();
				e.printStackTrace();
			}
		}

		req.setAttribute("error", String.valueOf(bError));
		req.setAttribute("errorText", sErrorText);

		req.setAttribute("pdfName", sOutputFilename);
		req.setAttribute("pdfUrl", REPOSITORY_URL + "/" + sOutputFilename);

		ServletContext context = getServletContext();
		RequestDispatcher dispatcher = context
				.getRequestDispatcher("/sampleresult.jsp");
		dispatcher.forward(req, res);
	}

	/**
	 * Utility method that loads an XML file and converts it into a string.
	 *
	 * @param file
	 * @return
	 * @throws Exception
	 */
	static String file2String(File file) throws Exception
	{

		FileInputStream fis = new FileInputStream(file);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		int buffSize = 1024;
		int bytesToWrite = -1;

		byte[] buff = new byte[buffSize];
		while ((bytesToWrite = fis.read(buff)) != -1)
		{
			baos.write(buff, 0, bytesToWrite);
		}

		fis.close();
		return baos.toString();
	}

}
