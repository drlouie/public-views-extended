function applyFormat()
{
  menu = document.getElementById("leftnav")
  if (menu != null)
  {
    menuItems = menu.getElementsByTagName("a");
    for (i = 0; i < menuItems.length; i++)
    {
      link = menuItems.item(i);
      if (document.location.href.indexOf(link.href, 0) == 0)
      {
        link.style.color = "black";
        link.style.textDecoration = "none";
      }
      else
      {
        link.style.color = 0x996666;
        link.style.textDecoration = "underline";
      }
    }
  }
}

/*
  Browsers do not reload pages when jumping between anchors on
  the same page. This means that the naviagation links will not
  be repainted with the appropriate decoration. The decoration
  is painted by applyFormat which is called by body onload which
  is not being called for anchor jumps. To overcome this, the
  navigation links call reNav(this) which will make the
  appropriate decoration changes.
*/

function reNav(o)
{
  //
  // Add the decoration back to the link for the current "page".
  //

  for (i = 0; i < menuItems.length; i++)
  {
    link = menuItems.item(i);
    if (link.href.indexOf(document.location) == 0)
    {
      link.style.color = "#996666";
      link.style.textDecoration = "underline";
    }
  }

  //
  // Remove the decoration to the link for the next "page" which
  // is about to become the current "page"
  //

  for (i = 0; i < menuItems.length; i++)
  {
    link = menuItems.item(i);
    if (link.href == o.href)
    {
      link.style.color = "black";
      link.style.textDecoration = "none";
    }
  }
}
