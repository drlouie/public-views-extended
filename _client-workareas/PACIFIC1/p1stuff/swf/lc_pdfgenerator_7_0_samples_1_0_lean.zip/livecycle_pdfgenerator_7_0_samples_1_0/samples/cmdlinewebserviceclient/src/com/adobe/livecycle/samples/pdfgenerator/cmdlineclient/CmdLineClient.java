/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

package com.adobe.livecycle.samples.pdfgenerator.cmdlineclient;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;

import com.adobe.livecycle.samples.pdfgenerator.PdfGenAccess;

/**
 * Basic implementation of a command line client wrapper around
 * PDF Generator web service Client.
 * @author slegge
 *
 */
public class CmdLineClient
{

	public static void main(String[] args)
	{

		//
		// build a StringBuffer to hold the help content
		//

		StringBuffer sbHelpString = new StringBuffer(
				"pdfg_client <filename|foldername> [-o <dir>] [-xml <config.file>]");
		sbHelpString.append("\n\n");
		sbHelpString.append("  * <filename> : when a file name is specified, the file is converted\n");
		sbHelpString.append("                 converted to PDF and returned to standard out; or,\n");
		sbHelpString.append("                 if the -o argument is used, is written to the specified\n");
		sbHelpString.append("                 directory.");
		sbHelpString.append("\n\n");
		sbHelpString.append("  * <foldername> : when a folder name is specified, all files in the\n");
		sbHelpString.append("                   folder (and all files contained in subfolders) are\n");
		sbHelpString.append("                   converted to PDF and written to the directory\n");
		sbHelpString.append("                   specified by the -o argument.");

		sbHelpString.append("\n\n");
		sbHelpString.append("  * -o <dir> : used to specify the output directory for PDF;\n");
		sbHelpString.append("               mandatory when using a foldername as the first argument;\n");
		sbHelpString.append("               optional when using a filename as the first\n");
		sbHelpString.append("               argument.");
		sbHelpString.append("\n\n");
		sbHelpString.append("  * -xml <config.file> : (optional) for specifying an XML config file\n");
		sbHelpString.append("                         that describes conversion details");
		sbHelpString.append("\n\n");
		sbHelpString.append("  NOTE: accompanying the pdfg command is a properties file (pdfg.properties)\n");
		sbHelpString.append("        which specifies the URL of the PDFG wsdl;\n");
		sbHelpString.append("        Example:\n");
		sbHelpString.append("        URL=http://localhost:8080/axis-aaes/services/PdfGenInterface?wsdl");
		sbHelpString.append("\n\n");

		//
		// if no arguments were provided (or -h or /h were provided) then
		// display the help text
		//

		if ((args.length == 0) || args[0].equalsIgnoreCase("-h")
				|| args[0].equalsIgnoreCase("/h"))
		{

			//
			// if there was an error with the args then show the error and return
			//

			System.out.print(sbHelpString.toString());
			return;
		}

		boolean bErrorInArgs = false;
		StringBuffer sbErrorText = new StringBuffer("ERROR:");

		//
		// read arguments
		//

		String sFileIn = (args.length >= 1) ? args[0] : "";
		String sFlag1 = (args.length >= 2) ? args[1] : "";
		String sValue1 = (args.length >= 3) ? args[2] : "";
		String sFlag2 = (args.length >= 4) ? args[3] : "";
		String sValue2 = (args.length >= 5) ? args[4] : "";

		//
		// validate the <filename|foldername> argument
		//

		File inputFile = new File(sFileIn);
		if (!inputFile.exists())
		{
			bErrorInArgs = true;
			sbErrorText.append("\n - File or folder '" + sFileIn
					+ "' does not exist.");
		}
		String sSourceDir = inputFile.getParent();
		String sSourceFilename = inputFile.getName();

		//
		// set the value of the output directory, if provided
		//

		boolean bOutputDirProvided = false;
		String sOutputDir = "";
		if (sFlag1.equalsIgnoreCase("-o"))
		{
			sOutputDir = sValue1;
			bOutputDirProvided = true;
		} else if (sFlag2.equalsIgnoreCase("-o"))
		{
			sOutputDir = sValue2;
			bOutputDirProvided = false;
		}

		//
		// set the value of the XML configuration file, if provided
		//

		boolean bXmlConfigFileProvided = false;
		String sXmlConfigFile = "";
		if (sFlag1.equalsIgnoreCase("-xml"))
		{
			sXmlConfigFile = sValue1;
			bXmlConfigFileProvided = true;
		} else if (sFlag2.equalsIgnoreCase("-xml"))
		{
			sXmlConfigFile = sValue2;
			bXmlConfigFileProvided = true;
		}

		//
		// validate the existance of the XML configuration file, if provided
		//

		File xmlConfigFile = new File(sXmlConfigFile);
		if (bXmlConfigFileProvided && !xmlConfigFile.exists())
		{
			bErrorInArgs = true;
			sbErrorText.append("\n - XML configuration file '" + sXmlConfigFile
					+ "' does not exist.");
		}

		String sConfigXML = "";
		if (bXmlConfigFileProvided)
		{
			try
			{
				sConfigXML = file2String(xmlConfigFile);
			} catch (Exception x)
			{
				System.err.println("Error reading provided config file '"
						+ sXmlConfigFile + "'; " + x.getMessage());
				x.printStackTrace();
			}
		}

		//
		// if there was an error with the args then show the error and return
		//

		if (bErrorInArgs)
		{
			System.err.print(sbErrorText.toString());
			return;
		}

		//
		// load the web service URL from the properties file
		//

		String sWebServiceURL = "";
		try
		{
			Properties props = new Properties();
			props.load(new FileInputStream("pdfg_client.properties"));
			sWebServiceURL = props.getProperty("url");
		} catch (Exception e)
		{
			System.err
					.print("Error reading web service URL from pdfg_client.properties file; "
							+ e.getMessage());
		}

		File fileIn = new File(sFileIn);
		if (fileIn.isFile() && !bOutputDirProvided)
		{

			//
			// generate the file and return the file as bytes to system out
			//

			try
			{

				//
				// not output dir was provided via cmd line args so we will return
				// the generated pdf to standard out -- however, we do need a temporary
				// place to store the generated pdf, so use the source dir
				//

				sOutputDir = sSourceDir;

				PdfGenAccess pdfGenAccess = new PdfGenAccess();
				String sOutputFile = pdfGenAccess.generatePDF(sWebServiceURL,
						sSourceDir, sSourceFilename, sOutputDir, sConfigXML);

				//
				// Open the PDF file
				//

				FileInputStream fstream = new FileInputStream(sOutputFile);

				//
				// Convert the input stream to a DataInputStream
				//

				DataInputStream in = new DataInputStream(fstream);

				//
				// Continue to read lines while there are still some left to read
				//

				while (in.available() != 0)
				{
					//
					// Print file line to screen
					//
					System.out.println(in.readLine());
				}
				in.close();

			} catch (Exception x)
			{
				System.err.println(x.getMessage());
				x.printStackTrace();
			}

			return;
		}

		//
		// assemble a list of file names to be converted based on the provided
		// <filename|foldername>
		//

		Collection filesToConvert = new ArrayList();
		if (fileIn.isFile() && bOutputDirProvided)
		{
			filesToConvert.add(fileIn.getAbsolutePath());
		}

		if (fileIn.isDirectory())
		{
			if (!bOutputDirProvided)
			{
				System.err
						.println("ERROR: Output directory must be provided (using -o arg) when specifying a folder as input.");
				return;
			}

			File[] files = fileIn.listFiles();
			for (int i = 0; i < files.length; i++)
			{
				filesToConvert.add(files[i].getAbsolutePath());
			}
		}

		//
		// submit each file for pdf generation
		//

		PdfGenAccess pdfGenAccess = new PdfGenAccess();
		Iterator iter = filesToConvert.iterator();
		while (iter.hasNext())
		{
			String sFilename = (String) iter.next();
			try
			{
				File file = new File(sFilename);
				String sSourceDir2 = file.getParent();
				String sSourceFilename2 = file.getName();
				pdfGenAccess.generatePDF(sWebServiceURL, sSourceDir2,
						sSourceFilename2, sOutputDir, sConfigXML);
			} catch (Exception x)
			{
				System.err.println(x.getMessage());
				x.printStackTrace();
			}
		}

	}

	/**
	 * Utilily method that loads an XML file and converts it to a string
	 * @param file
	 * @return
	 * @throws Exception
	 */
	static String file2String(File file) throws Exception
	{
		FileInputStream fis = new FileInputStream(file);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		int buffSize = 1024;
		int bytesToWrite = -1;

		byte[] buff = new byte[buffSize];
		while ((bytesToWrite = fis.read(buff)) != -1)
		{
			baos.write(buff, 0, bytesToWrite);
		}

		fis.close();
		return baos.toString();
	}

}
