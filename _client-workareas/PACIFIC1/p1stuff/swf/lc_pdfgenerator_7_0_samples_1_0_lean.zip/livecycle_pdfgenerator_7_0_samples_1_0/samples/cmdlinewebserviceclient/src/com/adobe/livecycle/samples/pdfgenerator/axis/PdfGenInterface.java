/**
 * PdfGenInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.adobe.livecycle.samples.pdfgenerator.axis;

public interface PdfGenInterface extends java.rmi.Remote {
    public com.adobe.livecycle.samples.pdfgenerator.axis.SubmitJobResponseType submitJob(com.adobe.livecycle.samples.pdfgenerator.axis.SubmitJobRequestType request) throws java.rmi.RemoteException;
    public com.adobe.livecycle.samples.pdfgenerator.axis.SubmitJobResponseType submitWebCaptureJob(com.adobe.livecycle.samples.pdfgenerator.axis.SubmitJobRequestType request) throws java.rmi.RemoteException;
    public com.adobe.livecycle.samples.pdfgenerator.axis.GetJobResultsResponseType getJobResults(com.adobe.livecycle.samples.pdfgenerator.axis.GetJobResultsRequestType request) throws java.rmi.RemoteException;
    public com.adobe.livecycle.samples.pdfgenerator.axis.GetJobResultsResponseType getJobResultsAsURL(com.adobe.livecycle.samples.pdfgenerator.axis.GetJobResultsRequestType request) throws java.rmi.RemoteException;
    public com.adobe.livecycle.samples.pdfgenerator.axis.GetConfigResponseType getConfigurationXML(com.adobe.livecycle.samples.pdfgenerator.axis.GetConfigRequestType request) throws java.rmi.RemoteException;
    public com.adobe.livecycle.samples.pdfgenerator.axis.DeleteJobResponseType deleteJob(com.adobe.livecycle.samples.pdfgenerator.axis.DeleteJobRequestType request) throws java.rmi.RemoteException;
}
