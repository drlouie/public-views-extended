
/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

package com.adobe.livecycle.samples.pdfgenerator;

import java.io.File;

import com.adobe.livecycle.samples.pdfgenerator.axis.PdfGenInterface;


/**
 * Utility class used by modified Axis generated class PdfGenSoapBindingStub
 * to hold arguements required for communication with web service.
 * @author slegge
 *
 */
public class TestArgs {

	public static File indir = null;
	public static File outdir = null;
	public static String srcFileName = null;
	public static int attachmentFormat = 0;
	public static String opName = null;
	
	public String indirprefix = "";
	public String locale = "";
	public int 		cycle = 1;
	public String testpath = System.getProperty("user.dir");
	public String configStr = "";
	public String xmpStr = "";
	
	public PdfGenInterface port;
	public String portAddress;
	
	String	urlType = "http";
	public String	host	= "";
	public String	hostAddrStr	= "";
	public int		tcpport = 80;
	public String	urlStr	= "";
		
	public  File sourceFile = null;
	
}
