/*************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2004 Adobe Systems Incorporated
 * All Rights Reserved
 *
 * NOTICE: Adobe permits you to use, modify, and distribute
 * this file in accordance with the terms of the Adobe license
 * agreement accompanying it. If you have received this file
 * from a source other than Adobe, then your use, modification,
 * or distribution of it requires the prior written permission
 * of Adobe.
 *
 *************************************************************/

package com.adobe.livecycle.samples.pdfgenerator;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.util.Iterator;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.xml.rpc.ServiceException;
import javax.xml.soap.AttachmentPart;

import org.apache.axis.Message;
import org.apache.axis.attachments.Attachments;
import org.apache.axis.attachments.AttachmentsImpl;

import org.apache.axis.client.Call;

import com.adobe.livecycle.samples.pdfgenerator.axis.GetJobResultsRequestType;
import com.adobe.livecycle.samples.pdfgenerator.axis.GetJobResultsResponseType;

/**
 * Utility class used by modified Axis generated class PdfGenSoapBindingStub to
 * hold arguements required for communication with web service.
 *
 * @author slegge
 *
 */
public class TestUtils
{

	public static void printTestHelp()
	{

		System.out.println("\nCommandline Config Help - ");
		System.out
				.println("1st arg - <locale>	- required	- client specified locale");
		System.out
				.println("2nd arg - <cycle>	- required	- # of test cycles to go thru' test files");
		System.out
				.println("3rd arg - <testpath>	- required	- location of test directory.");
		System.out
				.println("						Assumption: a directory hierachy is assumed under testpath:");
		System.out.println("						- subdir 'in' to store test files");
		System.out
				.println("						- subdir 'jobconfig' to store distiller job config files");
		System.out.println("						- subdir 'out' to store converted files");
		System.out.println();
		System.out
				.println("4th arg - <jobConfig>	- [Optional]	- job Config 'Name' of the jobConfig file in the jobconfig subdirectory under test path. For example, 'Standard.xml'.	Default: Standard.");
		System.out
				.println("5th arg - <xmp>			- [Optional]	- name of the xmp file in the 'xmp' subdirectory under test path. For example, 'Sample.xmp'.	Default: NO xmp.");
		System.out.println();
		System.out.println("For example,");
		System.out
				.println("	to execute WS test for 1 cycle using 'Standard.jobconfig' in jobconfig subdir : 1 'c:\\aestestdir' 'Standard'");
		System.out.println();
	}

	public static void printTestURLHelp()
	{

		System.out.println("\nCommandline Config Help - ");
		System.out
				.println("1st arg - <locale>	- required	- client specified locale");
		System.out
				.println("2nd arg - <cycle>	- required	- # of test cycles to go thru' test files");
		System.out
				.println("3rd arg - <urltype>		- required			- 'http' OR 'file' URL test");
		System.out
				.println("4th arg 	- <host>	- (required for http url test)	- host location of the test files.  The value '0' => is interpreted as 'localhost'.");
		System.out
				.println("5th arg 	- <tcpport>	- (required for http url test)	- TCP port to access the server for http url tests");
		System.out
				.println("6th arg 	- <url>		- (required for http url test)	- partial url that maps to the test path (see next argument).");
		System.out
				.println("									For example, you can set up a virtual directory named 'aes7test' in IIS that points to the test path - 'aes7test' => 'C:\\testdir'");
		System.out
				.println("									The partial url to place in the command line option would be '/aes7test/'");
		System.out.println();
		System.out
				.println("7th arg - <testpath>	- required	- location of test directory.");
		System.out
				.println("						Assumption: a directory hierachy is assumed under testpath:");
		System.out.println("						- subdir 'in' to store test files");
		System.out
				.println("						- subdir 'jobconfig' to store distiller job config files");
		System.out.println("						- subdir 'out' to store converted files");
		System.out.println();
		System.out
				.println("8th arg - <jobConfig>	- [Optional]	- job Config 'Name' of the jobConfig file in the jobconfig subdirectory under test path. For example, 'Standard.xml'.	Default: Standard.");
		System.out
				.println("9th arg - <xmp>			- [Optional]	- name of the xmp file in the 'xmp' subdirectory under test path. For example, 'Sample.xmp'.	Default: NO xmp.");
		System.out.println();
		System.out.println("For example,");
		System.out
				.println("	to execute WS test for 1 cycle using 'Standard.jobconfig' in jobconfig subdir : 1 'c:\\aestestdir' 'Standard'");
		System.out.println();
	}

	public static TestArgs getTestArgs(String testType, String insubdir,
			String[] args) throws IOException
	{

		TestArgs testArgs = new TestArgs();

		//
		// Set locale if available
		//
		if (args.length > 0)
		{
			testArgs.locale = args[0];
		} else
		{
			System.out
					.println("=> Error - missing commandline argument - locale\n");
			return null;
		}

		//
		// Set cycle and test path if available
		//
		if (args.length > 1)
		{
			testArgs.cycle = Integer.parseInt(args[1]);
		} else
		{
			System.out.println("=> Error - required commandline arguments\n");
			return null;
		}

		//
		// Set test path if available
		//
		if (args.length > 2)
		{
			testArgs.testpath = args[2];
		} else
		{
			System.out
					.println("=> Error - missing commandline argument - test path\n");
			return null;
		}

		//
		// Set input directory for test files
		//
		TestArgs.indir = new File(testArgs.testpath, insubdir);
		//
		// Set output directory for conversion results
		//
		TestArgs.outdir = new File(testArgs.testpath, "out");

		System.out.println("<< PDFG WebService " + testType + " Tests >>\n");
		System.out.println("In directory		: "
				+ TestArgs.indir.getCanonicalPath());
		System.out.println("Out directory		: "
				+ TestArgs.outdir.getCanonicalPath());

		//
		// Read job config/xmp if specified:
		//
		if (args.length > 3)
		{
			String ext = TestUtils.getExtension(args[3]);
			if (ext.equalsIgnoreCase("xml"))
				testArgs.configStr = TestUtils.getJobConfig(args[3],
						testArgs.testpath);
			else if (ext.equalsIgnoreCase("xmp"))
				testArgs.xmpStr = TestUtils.getXMPStr(args[3],
						testArgs.testpath);
		} else
		{
			System.out.println("Job config file		: <default>");
		}

		if (args.length > 4)
		{
			String ext = TestUtils.getExtension(args[4]);
			if (ext.equalsIgnoreCase("xml"))
				testArgs.configStr = TestUtils.getJobConfig(args[4],
						testArgs.testpath);
			else if (ext.equalsIgnoreCase("xmp"))
				testArgs.xmpStr = TestUtils.getXMPStr(args[4],
						testArgs.testpath);
		}

		//
		// return args:
		//
		return testArgs;
	}

	public static TestArgs getTestURLArgs(String testType, String[] args)
			throws IOException
	{

		TestArgs testArgs = new TestArgs();

		//
		// Set locale if available
		//
		if (args.length > 0)
		{
			testArgs.locale = args[0];
		} else
		{
			System.out
					.println("=> Error - missing commandline argument - locale\n");
			printTestHelp();
			return null;
		}

		//
		// Set cycle and test path if available
		//
		if (args.length > 1)
		{
			testArgs.cycle = Integer.parseInt(args[1]);
		} else
		{
			System.out.println("=> Error - required commandline arguments\n");
			return null;
		}

		//
		// Set urlType
		//
		int cur_index = 2;
		if (args.length > cur_index)
		{
			testArgs.urlType = args[cur_index];
			cur_index++;
			if (!testArgs.urlType.equalsIgnoreCase("http")
					&& !testArgs.urlType.equalsIgnoreCase("file"))
			{
				System.out.println("=> Error - invalid commandline argument"
						+ args[cur_index]);
				System.out.println("=> Expected : 'http' or 'file' url type.");

				return null;
			}
		} else
		{
			return null;
		}

		//
		// 'http' url test: get tcp port and partial url:
		//
		if (testArgs.urlType.equalsIgnoreCase("http"))
		{
			if (args.length > cur_index)
			{
				//
				// get host
				//
				testArgs.host = args[cur_index];
				try
				{
					testArgs.hostAddrStr = setHostAddr(testArgs.host);
				} catch (Exception e)
				{
					System.out.println("Unknown/Invalid Host - "
							+ testArgs.host);
					e.printStackTrace();
					return null;
				}
				cur_index++;
				if (args.length > cur_index)
				{
					//
					// TCP port
					//
					testArgs.tcpport = Integer.parseInt(args[cur_index]);
					cur_index++;
					if (args.length > cur_index)
					{
						//
						// get partial url
						//
						testArgs.urlStr = args[cur_index];
						cur_index++;

					} else
					{
						System.out
								.println("=> Error - missing commandline argument - 'partial url' to point to test files");
						return null;
					}
				} else
				{
					System.out
							.println("=> Error - missing commandline argument - TCP port");
					return null;
				}

			} else
			{
				System.out
						.println("=> Error - missing commandline argument - host");
				return null;
			}
		}

		//
		// Set test path if available
		//
		if (args.length > cur_index)
		{
			testArgs.testpath = args[cur_index];
			cur_index++;
		} else
		{
			System.out
					.println("=> Error - missing commandline argument - test path");
			return null;
		}

		//
		// Set input directory for test files
		//
		TestArgs.indir = new File(testArgs.testpath, "in");
		//
		// Set output directory for conversion results
		//
		TestArgs.outdir = new File(testArgs.testpath, "out");

		System.out.println("<< PDFG WebService submitJob(URL) Tests >>\n");
		System.out.println("In directory		: "
				+ TestArgs.indir.getCanonicalPath());
		System.out.println("Out directory		: "
				+ TestArgs.outdir.getCanonicalPath());

		//
		// Read job config/xmp if specified:
		//
		if (args.length > cur_index)
		{
			String ext = TestUtils.getExtension(args[cur_index]);
			if (ext.equalsIgnoreCase("xml"))
				testArgs.configStr = TestUtils.getJobConfig(args[cur_index],
						testArgs.testpath);
			else if (ext.equalsIgnoreCase("xmp"))
				testArgs.xmpStr = TestUtils.getXMPStr(args[cur_index],
						testArgs.testpath);

			cur_index++;
		} else
		{
			System.out.println("Job config file		: <default>");
		}

		if (args.length > cur_index)
		{
			String ext = TestUtils.getExtension(args[cur_index]);
			if (ext.equalsIgnoreCase("xml"))
				testArgs.configStr = TestUtils.getJobConfig(args[cur_index],
						testArgs.testpath);
			else if (ext.equalsIgnoreCase("xmp"))
				testArgs.xmpStr = TestUtils.getXMPStr(args[cur_index],
						testArgs.testpath);
		}

		//
		// return args:
		//
		return testArgs;
	}

	public static void getJobResults(String jobId, TestArgs testArgs)
			throws ServiceException, InterruptedException, RemoteException,
			IOException
	{
		//
		// Pick up results
		//
		int status = -1;
		int retCode = -1;
		int attachmentFormat = 1; // ask for MIME format
		
		//
		// Pick up results
		//
		File resultFile = null;
		File jdfFile = null;

		System.out.println("\njob ID: " + jobId);

		//
		// set values in req obj:
		//
		GetJobResultsRequestType getResultsRequest = new GetJobResultsRequestType();
		GetJobResultsResponseType getResultsResponse = null;

		//
		// set up req for jobResults:
		//
		getResultsRequest.setJobID(jobId);
		getResultsRequest.setResultAttachmentFormat(attachmentFormat);

		//
		// set result file path to download attachment:
		//
		resultFile = new File(TestArgs.outdir, changeExtension(
				testArgs.sourceFile.getName(), ".pdf"));

		do
		{
			Thread.sleep((long) 1000);
			System.out.println("\nChecking Status...");
			System.out
					.println("\nSending PDFG Soap request getJobResults()... ");

			//
			// get job result:
			//
			getResultsResponse = testArgs.port.getJobResults(getResultsRequest);

			//
			// get status/retCode:
			//
			status = getResultsResponse.getJobStatus();
			retCode = getResultsResponse.getReturnCode();

			System.out.println("Job ID: " + jobId);
			System.out.println("Status: " + status);

		} while ((retCode == 0) && (status == 1));

		//
		// ALL goes well:
		//
		if ((retCode == 0) && (status == 0))
		{

			//
			// downloaded attachment?
			//
			if (resultFile.exists())
			{
				System.out.println("ResultFile: "
						+ resultFile.getCanonicalPath());
			} else
			{
				System.out
						.println("ResultFile: null (no attachment found OR problem extracting attachment)");
			}

			//
			// has jdfData?
			//
			String jdfDataStr = getResultsResponse.getJdfData();
			if ((jdfDataStr != null) && (jdfDataStr.length() > 0))
			{
				jdfFile = new File(TestArgs.outdir, changeExtension(
						testArgs.sourceFile.getName(), ".jdf"));
				str2File(jdfDataStr, jdfFile);
				if (jdfFile.exists())
					System.out.println("Jdf File: "
							+ jdfFile.getCanonicalPath());
			}

			//
			// also get the result as URL:
			//
			getJobResultAsURL(jobId, testArgs);

		} else
		{
			System.out.println("getResults() returns error: Code: " + retCode
					+ " Message: " + getResultsResponse.getReturnMessage());
		}
	}

	public static void getJobResultAsURL(String jobId, TestArgs testArgs)
			throws ServiceException, IOException
	{
		//
		// Pick up results
		//
		int status = -1;
		int retCode = -1;

		String resultURL = "";
		String jdfURL = "";

		String resultFilename = "";
		File outFile = null;

		System.out.println();
		System.out.println("Sending PDFG SOAP request getJobResultsAsURL()...");
		System.out.println();

		GetJobResultsRequestType getResultsRequest = new GetJobResultsRequestType();
		GetJobResultsResponseType getResultsResponse = null;

		getResultsRequest.setJobID(jobId);
		getResultsResponse = testArgs.port
				.getJobResultsAsURL(getResultsRequest);

		//
		// get status/retCode:
		//
		status = getResultsResponse.getJobStatus();
		retCode = getResultsResponse.getReturnCode();

		System.out.println("Job ID: " + jobId);
		System.out.println("Status: " + status);
		//
		// ALL goes well--save output file if success
		//
		if ((retCode == 0) && (status == 0))
		{

			//
			// result and jdf URLs:
			//
			resultURL = getResultsResponse.getResultURL();
			jdfURL = getResultsResponse.getJdfURL();

			System.out.println("ResultURL: " + resultURL);
			System.out.println("jdfURL: " + jdfURL);

			//
			// download resultURL if present:
			//
			if ((resultURL != null) && !resultURL.equals(""))
			{
				System.out.println();

				//
				// Save output file if success Write result data to output file
				//
				resultFilename = changeExtension(testArgs.sourceFile.getName(),
						"-URL.pdf");
				System.out.println("ResultFilename: " + resultFilename);

				//
				// Write result data to output file
				//
				outFile = new File(TestArgs.outdir, resultFilename);

				URL baseURL = new URL(testArgs.portAddress);
				URL url = new URL(baseURL, resultURL);
				InputStream is = url.openStream();
				copyStreams(is, new FileOutputStream(outFile));

				System.out.println("Downloaded result file to : "
						+ outFile.getCanonicalPath());
			}

			//
			// download jdfURL if present:
			//
			if ((jdfURL != null) && !jdfURL.equals(""))
			{

				resultFilename = changeExtension(testArgs.sourceFile.getName(),
						"-URL.jdf");
				System.out.println("JDF Filename: " + resultFilename);

				//
				// Write result data to output file
				//
				outFile = new File(TestArgs.outdir, resultFilename);

				URL baseURL = new URL(testArgs.portAddress);
				URL url = new URL(baseURL, jdfURL);
				InputStream is = url.openStream();
				copyStreams(is, new FileOutputStream(outFile));

				System.out.println("Downloaded JDF file to : "
						+ outFile.getCanonicalPath());
			}
		} else
		{
			System.out.println("getResultsAsURL() returns error: Code: "
					+ retCode + " Message: "
					+ getResultsResponse.getReturnMessage());
		}
	}

	public static String setHostAddr(String host) throws UnknownHostException
	{

		String hostStr = "";

		//
		// '0' => localhost
		//
		if (host.equals("0") || host.equals("localhost"))
		{
			hostStr = InetAddress.getLocalHost().getHostAddress();
		} else
		{
			hostStr = InetAddress.getByName(host).getHostAddress();
		}
		return hostStr;
	}

	public static String setHttpURL(String hostAddrStr, int tcpport,
			String urlStr, File sourceFile) throws Exception
	{

		URL result = new URL("http", hostAddrStr, tcpport, urlStr + "in/"
				+ sourceFile.getName());
		return result.toString();
	}

	public static String setFileURL(File sourceFile)
			throws MalformedURLException
	{
		URL url = sourceFile.toURL();
		return url.toString();
	}

	public static String getJobConfig(String arg, String testpath)
	{

		String configStr = "";
		//
		// Read job config if specified in "jobconfig" subdir
		//
		File configdir = new File(testpath, "jobconfig");
		File configfile = new File(configdir, arg);

		try
		{
			if (configfile.exists())
			{
				configStr = file2String(configfile);
				System.out.println("Job config file		: "
						+ configfile.getCanonicalPath());

			} else
			{
				System.out.println("=> err - can't find job configfile file '"
						+ configfile.getCanonicalPath()
						+ "' => using default job config.");
			}
		} catch (Exception e)
		{
			System.out.println("\nCaught exception: " + e.toString());
			System.out.println();
			e.printStackTrace();
		}
		return configStr;
	}

	public static String getXMPStr(String arg, String testpath)
	{
		String xmpStr = "";

		File xmdir = new File(testpath, "xmp");
		File xmpfile = new File(xmdir, arg);

		try
		{
			if (xmpfile.exists())
			{
				xmpStr = file2String(xmpfile);
				System.out.println("XMP file		: " + xmpfile.getCanonicalPath());

			} else
			{
				System.out.println("=> err - can't find xmp file '"
						+ xmpfile.getCanonicalPath() + "' => won't use xmp.");
			}
		} catch (Exception e)
		{
			System.out.println("\nCaught exception: " + e.toString());
			System.out.println();
			e.printStackTrace();
		}

		return xmpStr;
	}

	/**
	 *
	 * myAddAttachment: hand code to add input document as a SOAP attachment to
	 * the SOAP call
	 *
	 * @param call
	 * @param sourceFile :
	 *            points to an accessible file path to pick up the document to
	 *            be sent as a SOAP attachment (e.g. "C:\input.doc")
	 *
	 * @param attachmentFormat
	 */
	public static void myAddAttachment(Call call)
	{
		//
		// NOTE: here we assume there is no more than one thread trying to
		// set 'srcFileName'
		//
		File infile = new File(TestArgs.indir, TestArgs.srcFileName);

		if (infile.exists())
		{
			String propType;
			String propVal;

			//
			// set SOAP attachment type: NOTE: here we assume there is no more
			// than one thread trying to set 'attachmentFormat'
			//
			if (TestArgs.attachmentFormat == 0)
			{
				//
				// DIME format
				//
				propType = Call.ATTACHMENT_ENCAPSULATION_FORMAT;
				propVal = Call.ATTACHMENT_ENCAPSULATION_FORMAT_DIME;
//
// System.out.println("Setting SOAP attachment format: " + "ATTACHMENT_ENCAPSULATION_FORMAT_DIME");
//
			} else
			{
				//
				// MIME format
				//
				propType = Call.ATTACHMENT_ENCAPSULATION_FORMAT;
				propVal = Call.ATTACHMENT_ENCAPSULATION_FORMAT_MIME;
//
// System.out.println("Setting SOAP attachment format: " + "ATTACHMENT_ENCAPSULATION_FORMAT_MIME");
//
			}
			call.setProperty(propType, propVal);

			//
			// add the attachment
			//
			DataHandler dhSource = new DataHandler(new FileDataSource(infile));
			call.addAttachmentPart(dhSource);

		}
	}

	/**
	 * myGetAttachment: hand code to extract converted result file from the SOAP
	 * attachment to a local disk location
	 *
	 * @param call
	 * @param resultFilePath :
	 *            accessible and writeable file path (including filename -- e.g.
	 *            "C:\output.pdf") where converted file is to be saved
	 *
	 * @throws Exception
	 */
	public static void myGetAttachment(Call call) throws Exception
	{

		//
		// NOTE: here we assume there is no more than one thread trying to
		// set outdir
		//
		if ((TestArgs.outdir == null) || ("".equals(TestArgs.outdir)))
			throw new IllegalArgumentException(
					"Null or empty String in result file path");

		//
		// get the response message:
		//
		Message respMsg = call.getResponseMessage();

		Attachments messageAttachments = respMsg.getAttachmentsImpl();
		if (null == messageAttachments)
			return;

		//
		// iterate and get the attachments:
		//
		int attachmentCount = messageAttachments.getAttachmentCount();

		//
		// bail out if can't find anything
		//
		if (attachmentCount == 0)
			return;
		else
		{
//
// System.out.println(); System.out.println("Found attachment(s) in
// Response message: " + attachmentCount);
//
		}

		//
		// Get the list of attachments:
		//
		AttachmentPart attachments[] = new AttachmentPart[attachmentCount];
		Iterator it = messageAttachments.getAttachments().iterator();
		int count = 0;
		while (it.hasNext())
		{
			AttachmentPart part = (AttachmentPart) it.next();
			attachments[count++] = part;
		}

		//
		// Get 'first' attachment only - this is considered the resultfile:
		//
		DataHandler dh = attachments[0].getDataHandler();

/**
		// find out SOAP attachment format in response message:
		int attachmentFormat = respMsg.getAttachmentsImpl().getSendType();

		if (attachmentFormat == AttachmentsImpl.SEND_TYPE_DIME)
			System.out.println("SOAP attachment format: " + "SEND_TYPE_DIME");
		else if (attachmentFormat == AttachmentsImpl.SEND_TYPE_MIME)
			System.out.println("SOAP attachment format: " + "SEND_TYPE_MIME");
		else
			System.out.println("SOAP attachment format: unknown: "
					+ attachmentFormat);
		System.out.println();
**/

		//
		// save to designated local disk:
		//
		File outFile = new File(TestArgs.outdir, changeExtension(
				TestArgs.srcFileName, ".pdf"));
		FileOutputStream os = new FileOutputStream(outFile);
		dh.writeTo(os);
		os.close();
	}

	public static String displayTime(long msec)
	{

		long sec = 0, min = 0, hr = 0;

		if (msec < 1000)
			return msec + " millisecs";

		if (msec >= 1000)
		{
			sec = msec / 1000;
			msec = msec % 1000;
			//
			// round up to sec
			//
			if (msec >= 500)
			{
				sec++;
			}
			if (sec >= 60)
			{
				min = sec / 60;
				sec = sec % 60;

				if (min >= 60)
				{
					hr = min / 60;
					min = hr % 60;
				}
			}
		}

		//
		// Display time as String
		//
		String tmStr = Long.toString(sec) + " secs";
		if (min > 0)
		{
			tmStr = Long.toString(min) + " min " + tmStr;
		}
		if (hr > 0)
		{
			tmStr = Long.toString(hr) + " hr " + tmStr;
		}
		return tmStr;
	}

	static String file2String(File file) throws Exception
	{

		FileInputStream fis = new FileInputStream(file);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();

		int buffSize = 1024;
		int bytesToWrite = -1;

		byte[] buff = new byte[buffSize];
		while ((bytesToWrite = fis.read(buff)) != -1)
		{
			baos.write(buff, 0, bytesToWrite);
		}

		fis.close();
		return baos.toString();
	}

	static void str2File(String str, File dest) throws IOException
	{

		if ((str == null) || (str.length() == 0) || (dest == null))
			return;

		byte bytes[] = str.getBytes();

		FileOutputStream fos = new FileOutputStream(dest);
		fos.write(bytes);
		fos.close();
	}

	public static void copyStreams(InputStream is, OutputStream os)
			throws IOException
	{

		int buffSize = 16384;
		long bytesToWrite = Long.MAX_VALUE;

		//
		// Copy streams
		//
		int bytesInBuff = 0;
		byte[] buff = new byte[buffSize];
		while ((bytesToWrite > 0) && ((bytesInBuff = is.read(buff)) != -1))
		{
			if (bytesToWrite < bytesInBuff)
			{
				bytesInBuff = (int) bytesToWrite;
			}
			os.write(buff, 0, bytesInBuff);
			bytesToWrite -= bytesInBuff;
		}

		os.flush();
	}

	public static String getExtension(String canonicalPath)
	{
		String result = "";

		if (canonicalPath != null)
		{
			int lastDot = canonicalPath.lastIndexOf('.');
			int lastSep = canonicalPath.lastIndexOf(File.separatorChar);
			int canonicalLength = canonicalPath.length();
			if ((-1 < lastDot) && (lastDot + 1 < canonicalLength) && // Pendantic
					(lastSep < lastDot))
			{
				result = canonicalPath.substring(lastDot + 1, canonicalLength);
			}
		}
		return result;
	}

	/**
	 * changes extension to new extension example: x =
	 * changeExtension("data.txt", ".java") will assign "data.java" to x.
	 */
	public static String changeExtension(String originalName,
			String newExtension)
	{
		int lastDot = originalName.lastIndexOf(".");
		if (lastDot != -1)
		{
			return originalName.substring(0, lastDot) + newExtension;
		} else
		{
			return originalName + newExtension;
		}
	}

}
