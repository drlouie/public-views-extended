================================================================================

SLIDESHOWPRO 1.6.x NOTES

Thanks for downloading SlideShowPro 1.6.x.


EXTENSION INSTALLATION / UPDATE
---------------------------------------------------------------------------------

If you are installing SlideShowPro for Flash for the first time, simply double
click on the MXP file to launch Macromedia/Adobe Extension Manager to install.

If you are updating an existing extension installation, launch Macromedia/Adobe
Extension Manager, select SlideShowPro, and click the "Remove" button. Then
double click on the MXP file in this archive to install.


FLAs CONTAINING OLD INSTANCES OF SSP
---------------------------------------------------------------------------------

If you have FLAs containing older instances of SlideShowPro for Flash, it is 
recommended that you *DO NOT* update your older FLA with 1.6.x. We found through
beta testing that some older FLAs did not update properly when adding 1.6.x to
them. With that, to use 1.6.x create a new FLA, drag an instance of it from the
Components panel to the Stage, then modify accordingly.


NEW IN 1.6.x: REVISED XML FILE TYPES
---------------------------------------------------------------------------------

If you've created slideshows using SlideShowPro 1.5.3 or earlier, you'll notice
that the XML File Type options have changed. Here are the new options:

* XML File Type: "Default"
Named "XML" in previous versions of SlideShowPro, this setting should be used when
loading your own XML file, or when loading data from SlideShowPro Director 1.0.9.9
or earlier.

* XML File Type: "Director"
This option should only be used with the new SlideShowPro Director 1.1. As noted
above, it should not be used with SlideShowPro Director 1.0.9.9 or earlier.


NEW IN 1.6.x: UPDATED PARAMETER NAMES
---------------------------------------------------------------------------------

In an effort to make SlideShowPro parameters better organized, a lot of parameters
in 1.6.x have changed names, options or both. If you are an older user of
SlideShowPro, you may wonder where some of the older options went. With that,
check out the new User Guide PDF included alongside this Read Me -- it has lots 
of new screenshots that show which parameters control which interface elements in 
SlideShowPro, and should hopefully make it even easier to customize and style.


================================================================================

Copyright 2007 Dominey Design Inc.

http://slideshowpro.net/