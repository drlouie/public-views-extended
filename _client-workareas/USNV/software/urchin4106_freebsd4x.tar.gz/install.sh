#!/bin/sh
#
# UNIX installation and upgrade script for Urchin4 
# Copyright (c) 2002 Urchin Software Corporation

# Set some shell variables and defaults for installation
PATH=/usr/bin:/usr/sbin:/bin:/sbin:$PATH
OS=`uname -s`
HOST=`uname -n`
INSTALLDIR=/usr/local/urchin4
PORT=9999

# Determine the current directory and the directory where the installation
# files are located.
CURRENTDIR=`pwd`
if [ "x$CURRENTDIR" = x ]; then
   echo "## Error: Unable to determine the current directory.  Exiting..."
   exit 1
fi
TEMPDIR=`dirname $0`
if [ "x$TEMPDIR" != x ] && [ "x$TEMPDIR" != x. ]; then
   INSTALLERDIR=$CURRENTDIR/$TEMPDIR
else
   INSTALLERDIR=$CURRENTDIR
fi

# Verify installation files are present in the installer's directory
INSPECTOR=$INSTALLERDIR/inspector
if [ ! -f "$INSPECTOR" ]; then
   echo "## Error: Missing inspector.  Exiting..."
   exit 1
fi
GUNZIP=$INSTALLERDIR/gunzip
if [ ! -f "$GUNZIP" ]; then
   if [ -f /usr/bin/gunzip ] && [ -x /usr/bin/gunzip ]; then
      GUNZIP=/usr/bin/gunzip
   else
      echo "## Error: Missing gunzip.  Exiting..."
      exit 1
   fi
fi
DIST=$INSTALLERDIR/urchin4.tar.gz
if [ ! -f "$DIST" ]; then
   echo "## Error: Missing urchin4.tar.gz.  Exiting..."
   exit 1
fi

# Get the version number for displaying to the user
NEWVERSION=`"$INSPECTOR" -v | cut -d ":" -f 2 | cut -d " " -f 3 | cut -c 1,2,3,4`
MAJORVERSION=`echo $NEWVERSION | cut -c 1`
MINORVERSION=`echo $NEWVERSION | cut -c 2,3,4`

# This sets up a portable way to have echo \c and echo -n be equivalent
case "`echo 'x\c'`" in 
  'x\c')  echo="echo -n" nnl= ;;      #BSD style echo
      x)  echo="echo"    nnl="\c" ;;  #SysV style echo
      *)  echo "$0 quitting: Can't set up echo command" 1>&2; exit 1 ;;
esac

# Determine username of the person executing this script
if [ $OS = SunOS ]; then
   if [ -f /usr/xpg4/bin/id ]; then
      MYLOGIN=`/usr/xpg4/bin/id -un`
   fi 
else
   MYLOGIN=`id -un`
fi

# Verify MYLOGIN was set
if [ x$MYLOGIN = x ]; then
   if [ ! x$USER = x ]; then
      MYLOGIN=$USER
   elif [ ! x$LOGNAME = x ]; then
      MYLOGIN=$LOGNAME
   else
      MYLOGIN=nobody
   fi
fi

# Set the default user for the web server.  This will be verified later...
if [ $MYLOGIN = root ]; then
   WUSER=nobody
else
   WUSER=$MYLOGIN
fi

# Set the default group for the user.  This will be verified later...
if [ $OS = SunOS ]; then
   if [ -f /usr/xpg4/bin/id ]; then
      WGROUP=`/usr/xpg4/bin/id -gn $WUSER`
   fi 
else
   WGROUP=`id -gn $WUSER`
fi
if [ x$WGROUP = x ]; then
   WGROUP=`groups $WUSER | awk '{print $1}'`
fi

# Set flags for command line options
dflag=0   # Install Directory flag
gflag=0   # Group flag
pflag=0   # Port flag
qflag=0   # Quiet flag
sflag=0   # Start scheduler and webserver flag
tflag=0   # Installation type (new or upgrade)
uflag=0   # User flag

# Check for a --help argument
for arg in "$@"; do
   if [ "x$arg" = x--help ]; then
      $0 -h
      exit 0
   fi
done

# Read in command line arguments and set flags and variables accordingly
while getopts d:g:hnmp:qs:u: OPT; do
   case $OPT in
      # Partially verify the installation directory
      d) if [ "x$OPTARG" != x ]; then
            if [ -r "$OPTARG" ] || [ -w "$OPTARG" ] || [ -x "$OPTARG" ] && [ ! -d "$OPTARG" ]; then
               echo "## Error: $OPTARG already exists and is not a directory.  Exiting."
               exit 1
            fi
            # Perform remainder of directory checks at end of the getopts while loop right after
            # selection of installation type.
            INSTALLDIR=$OPTARG
            dflag=1
         fi
      ;;
      # Verify the group
      g) if [ x$OPTARG != x ]; then
            if [ ! -d /tmp/.urchin$$ ] && [ ! -f /tmp/.urchin$$ ] && [ ! -r /tmp/.urchin$$ ] && [ ! -w /tmp/.urchin$$ ] && [ ! -x /tmp/.urchin$$ ]; then
               touch /tmp/.urchin$$
               chgrp $OPTARG /tmp/.urchin$$ > /dev/null 2>&1
               if [ $? != 0 ]; then
                  echo "## Error: Unable to change the group to $groupin.  The group is either"
                  echo "## invalid or you don't have permission to change files to that group."
                  echo "## Exiting."
                  exit 1
               else
                  WGROUP=$OPTARG
                  gflag=1
               fi
               if [ -f /tmp/.urchin$$ ]; then
                  rm /tmp/.urchin$$
               fi
            else
               echo "## Error: Unable to test group argument.  Exiting."
            fi
         fi
      ;;
      # Print help information
      h) echo "Usage: $0 [-h] [-q] [-d installdir] [-p port] [-g group] [-u user] [-s (yes|no)] [-n|-m]"
         echo "   where:"
         echo "      -h   prints this message"
         echo "      -q   operates the installer in quiet mode (disables some messages)"
         echo "      -d   specifies the installation directory"
         echo "      -p   specifies the port for the webserver"
         echo "      -g   specifies the group for the webserver"
         echo "      -u   specifies the user for the webserver"
         echo "      -s   specifies whether to start the Urchin webserver and scheduler"
         echo "      -n   specifies a new installation"
         echo "      -m   specifies an upgrade installation"
         echo ""
         exit 0
      ;;
      # New installation
      n) if [ $tflag -eq 0 ]; then
            upgrade=0
            tflag=1
         else
            if [ $upgrade -eq 1 ]; then
               echo "## Error: The -n option can not be specified at the same time with -m.  Exiting."
               exit 1
            fi
         fi
      ;;
      # Upgrade installation
      m) if [ $tflag -eq 0 ]; then
            upgrade=1
            tflag=1
         else
            if [ $upgrade -eq 0 ]; then
               echo "## Error: The -m option can not be specified at the same time with -n.  Exiting."
               exit 1
            fi
         fi
      ;;
      # Verify the port
      p) if [ x$OPTARG != x ]; then
            if [ $MYLOGIN != root ] && [ $OPTARG -lt 1024 ]; then
               echo "## Error: A port number greater than or equal to 1024 must be specified"
               echo "## if you are not root.  Exiting."
               exit 1
            else
               PORT=$OPTARG
               pflag=1
            fi
         fi
      ;;
      # Set the quiet flag
      q) qflag=1
      ;;
      # Set the start flag
      s) if [ x$OPTARG != x ]; then
            if [ x$OPTARG = xyes ]; then
               startservers=1
            elif [ x$OPTARG = xno ]; then
               startservers=0
            else
               echo "## Error: Improper argument supplied after -s.  Exiting."
               exit 1
            fi
            sflag=1
         fi
      ;;
      # Verify the user
      u) if [ x$OPTARG != x ]; then
            if [ $OPTARG = root ]; then
               echo "## Error: You cannot run the webserver as root.  Exiting."
               exit 1
            fi
            id $OPTARG > /dev/null 2>&1
            if [ ! $? = 0 ]; then
               echo "## Error: Invalid user: $OPTARG.  Exiting."
               exit 1
            elif [ $OPTARG != $MYLOGIN ] && [ $MYLOGIN != root ]; then
               echo "## Error: You must be root to specify a different user.  Exiting."
               exit 1
            else
               WUSER=$OPTARG
               uflag=1
            fi
         fi
      ;;
      \?) $0 -h
         exit 1
      ;;
   esac  
done  

# Print installation splash screen
echo ""
echo "     Welcome to the Urchin $MAJORVERSION.$MINORVERSION Installation and Upgrade Utility"
echo ""
if [ $qflag -eq 0 ]; then
   echo "This utility is capable of creating a new installation or upgrading a"
   echo "previous installation of Urchin 4."
   echo ""
fi

# Prompt user for new install vs upgrade
if [ $tflag -eq 0 ]; then
   wflag=0
   while [ $wflag -eq 0 ]; do
      echo  "-> Which type of installation would you like to perform? ([n]ew/upgrade)?"
      $echo "   Enter 'n' for new or 'u' for upgrade: ${nnl}"
      read ans
      if [ x$ans = x ] || [ x$ans = xn ] || [ x$ans = xN ]; then
         wflag=1
         upgrade=0
      elif [ x$ans = xu ] || [ x$ans = xU ]; then
         wflag=1
         upgrade=1
      else
         echo ""
         echo "You did not enter a valid response.  Please try again."
         echo ""
      fi
   done  
fi

# Finish verification of directory entered as a command line option based on installation type.
if [ $dflag -eq 1 ]; then
   # Check if $INSTALLDIR does not exist
   if [ ! -d "$INSTALLDIR" ]; then
      if [ $upgrade -eq 0 ]; then
         mkdir "$INSTALLDIR"
         if [ $? -gt 0 ]; then
            echo "## Error: Failed to make directory: $INSTALLDIR.  Exiting."
            exit 1
         fi
      else
         echo "## Error: Unable to upgrade Urchin since the specified directory,"
         echo "## $INSTALLDIR, does not exist.  Exiting."
         exit 1
      fi
   # Check if $INSTALLDIR is not writeable
   elif [ ! -w "$INSTALLDIR" ]; then
      echo "## Error: The installation directory, $INSTALLDIR,"
      echo "## is not writeable for $MYLOGIN.  You may need to rerun this script"
      echo "## as root or as a different user.  Exiting."
      exit 1
   else
      # Check if this is a valid directory for an upgrade
      if [ $upgrade -eq 1 ]; then
         if [ ! -f "$INSTALLDIR/bin/urchin" ]; then
            echo "## Error: The specified installation directory, $INSTALLDIR,"
            echo "## does not contain the necessary files for upgrading.  Exiting."
            exit 1
         fi
      fi
   fi
fi

# Verify the port is available if this is a new installation and the port was a command line option.
if [ $upgrade -eq 0 ] && [ $pflag -eq 1 ]; then
   "$INSPECTOR" -P $PORT
   if [ $? -ne 0 ]; then
      echo "## Error: The specified port, $PORT, is not available.  Exiting."
      exit 1
   fi
fi

# Print appropriate installation information based on the type of installation
if [ $qflag -eq 0 ]; then
   echo ""
   if [ $upgrade -eq 1 ]; then
      echo "Please make sure to backup your current installation of Urchin 4 before"
      echo "using this installer to upgrade."
      echo ""
   fi
   echo "Please make sure you have read the install.txt file that unpacks with"
   echo "this installer before continuing with the installation.  You should be"
   echo "prepared to provide the following information if the script requires it:"
   echo ""
   echo "1) An unused port number for the Urchin webserver. If you are not"
   echo "   superuser when running this installation script, then you will not be"
   echo "   allowed to choose a port number lower than 1024."
   echo "2) A legitimate non-root user account, which will be used to set"
   echo "   ownership on the files in the installed distribution.  Also the"
   echo "   webserver will run as this user. If you are not superuser when"
   echo "   running this installation script, then your login will be used"
   echo "   automatically as the user."
   echo "3) A group name to use for group ownership of files. If you are not"
   echo "   superuser when running this installation script, then your default"
   echo "   group will be used automatically."
   echo "" 
   echo "Default values will be suggested in square brackets at each place where"
   echo "input is required, but you will have to verify that these suggested"
   echo "values are correct for your system. Improperly set values may cause your"
   echo "Urchin 4 distribution to operate incorrectly."
   echo ""
   echo "Urchin 4 installs and uses a lightweight Apache webserver, specifically"
   echo "configured for Urchin's web-based administration and report delivery."
   echo "More detailed technical information can be obtained at"
   echo "http://help.urchin.com/apache.html."
   echo ""
   $echo "-> Press return to continue or CNTRL-C to exit: ${nnl}"
   read IN
   echo ""
fi

# ---Installation Directory---
# Perform necessary checks on the installation directory entered by the user
if [ $dflag -eq 0 ]; then
   wflag=0
   while [ $wflag -eq 0 ]; do 
      if [ $upgrade -eq 0 ]; then
         $echo "-> Please specify a directory for the installation of Urchin 4 [$INSTALLDIR]: ${nnl}" 
      else
         $echo "-> Please specify the directory where Urchin 4 was installed [$INSTALLDIR]: ${nnl}"
      fi
      read dir
      echo ""

      # Assign default answer to $dir if nothing was entered
      if [ "x$dir" = x ]; then
         dir=$INSTALLDIR
      fi

      # Verify that $dir is not already a file
      if [ -r "$dir" -o -w "$dir" -o -x "$dir" ] && [ ! -d "$dir" ]; then
         if [ $upgrade -eq 0 ]; then
            echo "$dir already exists and is not a directory."
         else
            echo "$dir is not a directory."
         fi
         echo "Please specify a different location."
         echo ""
      # Check if $dir does not exist
      elif [ ! -d "$dir" ]; then
         if [ $upgrade -eq 0 ]; then
            echo "The specified directory, $dir, does not exist."
            echo ""
            wflag2=0
            while [ $wflag2 -eq 0 ]; do
               $echo "-> Do you want this script to create it? ([y]/n): ${nnl}"
               read ans
               echo ""
               if [ x$ans = x ] || [ x$ans = xy ] || [ x$ans = xY ]; then
                  wflag2=1
                  mkdir "$dir"
                  if [ $? -gt 0 ]; then
                     echo "## Error: Failed to make directory: $dir"
                     echo "## Exiting."
                     exit 1
                  fi
                  INSTALLDIR=$dir
                  wflag=1
               elif [ x$ans = xn ] || [ x$ans = xN ]; then
                  wflag2=1
                  echo "Please specify a different directory."
                  echo ""
               else
                  echo "You did not enter a valid response.  Please try again."
                  echo ""
               fi
            done
         else
            echo "The specified directory, $dir, does not exist."
            echo ""
         fi
      elif [ ! -w "$dir" ]; then
         if [ $upgrade -eq 0 ]; then
            echo "$dir is not writeable for $MYLOGIN."
            echo "Please select another directory."
            echo ""
         else
            echo "$dir is not writeable for $MYLOGIN."
            echo "You may need to rerun this script as root or as a different user."
            echo ""
         fi
      else
         if [ $upgrade -eq 0 ]; then
            wflag2=0
            echo "The directory, $dir, already exists."
            echo ""
            while [ $wflag2 -eq 0 ]; do
               $echo "-> Are you sure you want to install in this location? (y/[n]): ${nnl}"
               read ans
               echo ""
               if [ x$ans = x ] || [ x$ans = xn ] || [ x$ans = xN ]; then
                  wflag2=1
               elif [ x$ans = xy ] || [ x$ans = xY ]; then
                  wflag2=1
                  INSTALLDIR=$dir
                  wflag=1
               else
                  echo "You did not enter a valid response.  Please try again."
                  echo ""
               fi
            done
         else
            if [ ! -f "$dir/bin/urchin" ]; then
               echo "The specified directory does not contain the necessary files for"
               echo "performing an upgrade."
               echo ""
            else
               INSTALLDIR=$dir
               wflag=1
            fi
         fi
      fi

      # Check if the installation directory was set to the current working directory
      if [ $wflag -eq 1 ]; then
         cwdflag=0
         if [ -f "$INSTALLDIR/inspector" ] && [ -f "$INSTALLDIR/install.sh" ]; then 
            if [ $upgrade -eq 0 ]; then
               echo "You appear to be installing into the current directory, which is where"
               echo "the installation files are located."
               echo ""
            else
               echo "You appear to be upgrading files in the current directory, which is where"
               echo "the installation files are located."
               echo ""
            fi
            wflag2=0
            while [ $wflag2 -eq 0 ]; do
               $echo "-> Are you sure this is what you want to do? (y/[n]): ${nnl}"
               read ans
               echo ""
               if [ x$ans = x ] || [ x$ans = xn ] || [ x$ans = xN ]; then
                  wflag2=1;
                  wflag=0;
                  echo "Please specify a different location."
                  echo ""
               elif [ x$ans = xy ] || [ x$ans = xY ]; then
                  cwdflag=1
                  wflag2=1
               else
                  echo "You did not enter a valid response.  Please try again."
                  echo ""
               fi
            done
         fi
      fi
   done
fi

# Verify this is an upgrade and not a downgrade
if [ $upgrade -eq 1 ]; then
   # Check the version number to make sure this is an upgrade and not a downgrade.
   OLDVERSION=`"$INSTALLDIR/bin/urchin" -v | cut -d ":" -f 2 | cut -d " " -f 3 | cut -c 1,2,3,4`
   if [ $NEWVERSION -lt $OLDVERSION ]; then
      echo "## Error: You appear to be downgrading Urchin from version $OLDVERSION"
      echo "## to version $NEWVERSION. Exiting."
      exit 1
   fi
fi

# Shutdown the webserver and scheduler if they are running
if [ -f "$INSTALLDIR/var/httpd.pid" ] || [ -f "$INSTALLDIR/var/urchind.pid" ] || [ -f "$INSTALLDIR/var/urchinwebd.pid" ]; then
   echo "Stopping Urchin webserver and scheduler..."
   if [ -f "$INSTALLDIR/bin/wrapper" ]; then
      cd "$INSTALLDIR/bin"
      ./wrapper -disable
      cd "$CURRENTDIR"
   else
      "$INSTALLDIR/bin/urchinctl" stop
   fi
   sleep 2
   echo "done"
   echo ""
fi

# Verify the port is available if this is an upgrade and the port was a command line option.
if [ $upgrade -eq 1 ] && [ $pflag -eq 1 ]; then
   "$INSPECTOR" -P $PORT
   if [ $? -ne 0 ]; then
      echo "## Error: The specified port, $PORT, is not available.  Exiting."
      exit 1
   fi
fi

# ---Webserver Configuration---
# Prompt user for the webserver port
if [ $pflag -eq 0 ]; then
   wflag=0
   while [ $wflag -eq 0 ]; do
      if [ $upgrade -eq 0 ]; then
         $echo "-> Choose a port number for your webserver to use [$PORT]: ${nnl}"
      else
         port=0
         if [ -r "$INSTALLDIR/var/urchinwebd.conf" ]; then
            port=`grep "^Port" "$INSTALLDIR/var/urchinwebd.conf" | cut -d " " -f 2`
         elif [ -r "$INSTALLDIR/etc/httpd.conf" ]; then
            port=`grep "^Port" "$INSTALLDIR/etc/httpd.conf" | cut -d " " -f 2`
         fi
         if [ $port -ne 0 ]; then
            PORT=$port
         fi
         $echo "-> Choose a port number for your webserver to use [$PORT]: ${nnl}"
      fi
      read portin
      echo ""
      if [ x$portin = x ]; then
         portin=$PORT
      fi
      if [ $MYLOGIN != root ] && [ $portin -lt 1024 ]; then
         echo "You must choose a port number greater than or equal to 1024 if you are"
         echo "not logged in as root.  Please choose a different port"
         echo ""
      else
         # Verify the port is available
         "$INSPECTOR" -P $portin
         if [ $? -ne 0 ]; then
            echo "The port $portin is not available.  Please choose a different port"
            echo ""
         else
            PORT=$portin
            wflag=1
         fi
      fi
   done
fi

# Determine and verify the user
if [ $uflag -eq 0 ]; then
   # If we're root, we can choose which user to run the webserver as
   if [ $MYLOGIN = root ]; then
      wflag=0
      while [ $wflag -eq 0 ]; do
         if [ $upgrade -eq 0 ]; then
            $echo "-> Choose a user for your webserver to run as [$WUSER]: ${nnl}"
         else
            if [ -r "$INSTALLDIR/var/urchinwebd.conf" ]; then
               user=`grep "^User" "$INSTALLDIR/var/urchinwebd.conf" | cut -d " " -f 2`
            elif [ -r "$INSTALLDIR/etc/httpd.conf" ]; then
               user=`grep "^User" "$INSTALLDIR/etc/httpd.conf" | cut -d " " -f 2`
            fi
            if [ x$user != x ]; then
               WUSER=$user
            fi
            $echo "-> Choose a user for your webserver to run as [$WUSER]: ${nnl}"
         fi
         read userin
         echo ""
         if [ x$userin = x ]; then
            userin=$WUSER
         fi
         if [ $userin = root ]; then
            echo "You cannot run the webserver as root. Please choose another user."
            echo ""
         else
            id $userin > /dev/null 2>&1
            if [ $? -ne 0 ]; then
               echo "$userin is not a valid user on this system. Please choose another user." 
               echo ""
            else
               WUSER=$userin
               wflag=1
            fi
         fi
      done
   fi
fi

# Determine and verify the group
if [ $gflag -eq 0 ]; then
   # If we're root, we can choose which group to run the webserver as
   if [ $MYLOGIN = root ]; then
      wflag=0
      while [ $wflag -eq 0 ]; do
         if [ $OS = SunOS ]; then
            if [ -f /usr/xpg4/bin/id ]; then
               WGROUP=`/usr/xpg4/bin/id -gn $WUSER`
            fi 
         else
            WGROUP=`id -gn $WUSER`
         fi
         if [ x$WGROUP = x ]; then
            WGROUP=`groups $WUSER | awk '{print $1}'`
         fi
         if [ $upgrade -eq 0 ]; then
            $echo "-> Choose a group for your webserver to run as [$WGROUP]: ${nnl}"
         else
            if [ -r "$INSTALLDIR/var/urchinwebd.conf" ]; then
               group=`grep "^Group" "$INSTALLDIR/var/urchinwebd.conf" | cut -d " " -f 2`
            elif [ -r "$INSTALLDIR/etc/httpd.conf" ]; then
               group=`grep "^Group" "$INSTALLDIR/etc/httpd.conf" | cut -d " " -f 2`
            fi
            if [ x$group != x ]; then
               WGROUP=$group
            fi
            $echo "-> Choose a group for your webserver to run as [$WGROUP]: ${nnl}"
         fi
         read groupin
         echo ""
         if [ x$groupin = x ]; then
            groupin=$WGROUP
         fi
         touch "$INSTALLDIR/.urchin$$"
         chgrp $groupin "$INSTALLDIR/.urchin$$" > /dev/null 2>&1
         if [ $? != 0 ]; then
            echo "Unable to change the group to $groupin.  Please choose another group"
            echo ""
         else
            WGROUP=$groupin
            wflag=1
         fi
         rm "$INSTALLDIR/.urchin$$"
      done
   fi
fi

# Verify the user wishes to start the webserver and scheduler
if [ $sflag -eq 0 ]; then
   wflag=0
   while [ $wflag -eq 0 ]; do
      echo  "-> Would you like the installer to start the Urchin webserver and"
      $echo "   scheduler at the end of this installation? ([y]/n): ${nnl}"
      read ans
      echo ""
      if [ x$ans = x ] || [ x$ans = xy ] || [ x$ans = xY ]; then
         startservers=1
         wflag=1
      elif [ x$ans = xn ] || [ x$ans = xN ]; then
         startservers=0
         wflag=1
      else
         echo "You did not enter a valid response.  Please try again."
         echo ""
      fi
   done
fi

# Print summary information of installation
echo ""
if [ $upgrade -eq 0 ]; then
   echo "Summary information for Installing Urchin $MAJORVERSION.$MINORVERSION"
   echo ""
else
   echo "Summary information for Upgrading to Urchin $MAJORVERSION.$MINORVERSION"
   echo ""
fi
echo "Installation Directory: $INSTALLDIR"
echo "Webserver Port:         $PORT"
echo "Webserver User:         $WUSER"
echo "Webserver Group:        $WGROUP"
echo ""
if [ $startservers -eq 1 ]; then
   echo "The Urchin webserver and scheduler will be started at the end of the"
   echo "installation."
else
   echo "The Urchin webserver and scheduler will not be started at the end of"
   echo "the installation."
fi
echo ""
if [ $qflag -eq 0 ]; then
   $echo "-> Press return to continue or CNTRL-C to exit: ${nnl}"
   read IN
   echo ""
fi

# Archive etc configuration files
if [ $upgrade -eq 1 ]; then
   $echo "Archiving configuration files...${nnl}"
   echo "done"
   echo ""
   echo "NOTE: To users who have customized any of the following files:"
   if [ -f "$INSTALLDIR/etc/session.conf" ]; then
      echo "   $INSTALLDIR/etc/session.conf"
      mv "$INSTALLDIR/etc/session.conf" "$INSTALLDIR/etc/session.conf.sav"
   fi
   if [ -f "$INSTALLDIR/etc/urchin.conf" ]; then
      echo "   $INSTALLDIR/etc/urchin.conf"
      mv "$INSTALLDIR/etc/urchin.conf" "$INSTALLDIR/etc/urchin.conf.sav"
   fi
   if [ -f "$INSTALLDIR/etc/httpd.conf.template" ]; then
      echo "   $INSTALLDIR/etc/httpd.conf.template"
      mv "$INSTALLDIR/etc/httpd.conf.template" "$INSTALLDIR/etc/httpd.conf.template.sav"
   fi
   if [ -f "$INSTALLDIR/var/urchinwebd.conf.template" ]; then
      echo "   $INSTALLDIR/var/urchinwebd.conf.template"
      mv "$INSTALLDIR/var/urchinwebd.conf.template" "$INSTALLDIR/var/urchinwebd.conf.template.sav"
   fi
   echo ""
   echo "The above files have been renamed with a .sav extension.  Any"
   echo "customizations made to those files will also need to be made in the"
   echo "newly installed files."
   echo ""
   if [ $qflag -eq 0 ]; then
      $echo "-> Press return to continue: ${nnl}"
      read IN
      echo ""
   fi
fi

# Uncompress files into the installation directory
$echo "Uncompressing and installing Urchin 4...${nnl}"
"$GUNZIP" -c "$DIST" | (cd "$INSTALLDIR"; tar xf -)
sleep 2
echo "done"
echo ""

# Remove outdated files (for upgrade only)
if [ $upgrade -eq 1 ]; then
   # For upgrade from 4.006 to 4.100+
   rm -f "$INSTALLDIR/bin/httpd"
   rm -f "$INSTALLDIR/bin/httpdctl.sh"
   rm -f "$INSTALLDIR/bin/urchindctl.sh"
   rm -f "$INSTALLDIR/bin/wrapper"
   rm -f "$INSTALLDIR/etc/httpd.conf"
   rm -f "$INSTALLDIR/etc/httpd.conf.template"
   rm -f "$INSTALLDIR/etc/httpd.conf.template_unix"
   # For upgrade from 4.002 to 4.003+
   rm -f "$INSTALLDIR/htdocs/ujs/calender.js"
   # For upgrade from 4.101 to 4.102+
   rm -f "$INSTALLDIR/util/setup_conf.sh"
fi

# Create webserver configuration template and startup/shutdown script
$echo "Creating webserver configuration...${nnl}"
sed -e "s^XXXUSERXXX^${WUSER}^" -e "s^XXXGROUPXXX^${WGROUP}^" "$INSTALLDIR/var/urchinwebd.conf.template_unix" > "$INSTALLDIR/var/urchinwebd.conf.template"
rm -f "$INSTALLDIR/var/urchinwebd.conf.template_unix"
sed -e "s^XXXINSTALLDIRXXX^${INSTALLDIR}^" "$INSTALLDIR/util/urchin4_daemons.template" > "$INSTALLDIR/util/urchin4_daemons"
sleep 2
echo "done"
echo ""

# Initialize the configuration databases for new installs
if [ $upgrade -eq 0 ]; then
   $echo "Initializing the Urchin configuration databases...${nnl}"
   "$INSTALLDIR/util/uconf-import" -r -f "$INSTALLDIR/util/initialdb.config"
   sleep 2
   echo "done"
   echo ""
fi

# Set the user and group on the installed files.
# Only change owner if installer is run as root
$echo "Setting file ownership and permissions...${nnl}"
if [ $MYLOGIN = root ]; then
   chown -R $WUSER "$INSTALLDIR"
fi
chgrp -R $WGROUP "$INSTALLDIR"
# Use the installed inspector in repair mode to set the permissions of the files
"$INSTALLDIR/util/inspector" -R
if [ $? -ne 0 ]; then
   echo ""
   echo "## Error: Problems setting permissions on the distribution files"
   echo ""
else
   sleep 2
   echo "done"
   echo ""
fi

# Start the Urchin webserver and scheduler daemon
if [ $startservers -eq 1 ]; then
   echo "Starting the Urchin webserver and scheduler daemon..."
   "$INSTALLDIR/bin/urchinctl" -p $PORT start
   sleep 2
   echo "done"
   echo ""
else
   "$INSTALLDIR/bin/urchinctl" -p $PORT status > /dev/null 2 >& 1
fi

# Administrative announcements
echo ""
echo "Installation complete in $INSTALLDIR"
echo ""
if [ $startservers -eq 1 ]; then
   echo "The Urchin Administration GUI should be ready to use."
   echo "The URL is http://${HOST}:${PORT}"
else
   echo "The Urchin Administration GUI will be ready to use after you start the"
   echo "webserver and scheduler.  To start the webserver and scheduler, change"
   echo "into $INSTALLDIR/bin and execute the command:"
   echo ""
   echo "   urchinctl start"
   echo ""
   echo "The URL for the Administration GUI is http://${HOST}:${PORT}"
fi
if [ $qflag -eq 0 ]; then
   echo ""
   echo "A username and password are required to login to the Urchin Administration"
   echo "interface. The default username is admin and the default password is"
   echo "urchin. After logging in, a wizard will walk you through the process of"
   echo "licensing and configuring the software. One of the configuration steps"
   echo "is to set the password for the admin user. We strongly recommend that"
   echo "you change the password from the default value to something more secure."
   echo ""
   echo "You can use the urchinctl program in the bin directory to start and stop"
   echo "the Urchin daemons"
   echo ""
   echo "E.g. urchinctl start"
   echo "     urchinctl stop"
   echo ""
   echo "See your Urchin systems administration guide for more details"
   echo ""
fi
